package com.nb.Training;
public class Evennum {

	public static void main(String[] args) {
		int n=200;
		System.out.println("Even Number from 1 to "+n+" are:");
		for (int i=1;i<=n; i++) {
			if (i%2==0) {
				System.out.println(i+" ");
			}
		}
	}
}