package com.nb.Training;
public abstract class Instrument
{
public abstract void Play();
}