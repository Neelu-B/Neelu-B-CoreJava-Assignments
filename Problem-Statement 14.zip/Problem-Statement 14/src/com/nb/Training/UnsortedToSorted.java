package com.nb.Training;

public class UnsortedToSorted {
	
	static node head1 = null;
	static node head2 = null;

	static class node
	{
	int data;
	node next;
	};

	static void setData(node head)
	{
	node tmp;

	tmp = head;

	while (tmp != null)
	{
		System.out.print(tmp.data + " -> ");
		tmp = tmp.next;
	}
	}

	
	static node getData(node head, int num)
	{
	
	node temp = new node();
	node tail = head;

	// Insert data into the temporary
	// node and point it's next to null
	temp.data = num;
	temp.next = null;

	// Check if head is null, create a
	// linked list with temp as head
	// and tail of the list
	if (head == null)
	{
		head = temp;
		tail = temp;
	}

	
	else
	{
		while (tail != null)
		{
		if (tail.next == null)
		{
			tail.next = temp;
			tail = tail.next;
		}
		tail = tail.next;
		}
	}

	return head;
	}

	
	static node mergelists()
	{
	node tail = head1;

	while (tail != null)
	{
		if (tail.next == null &&
			head2 != null)
		{
		tail.next = head2;
		break;
		}
		tail = tail.next;
	}

	return head1;
	}

	static void sortlist()
	{
	node curr = head1;
	node temp = head1;

	while (curr.next != null)
	{
		temp = curr.next;
		while (temp != null)
		{
		if (temp.data < curr.data)
		{
			int t = temp.data;
			temp.data = curr.data;
			curr.data = t;
		}
		temp = temp.next;
		}
		curr = curr.next;
	}
	}

	public static void main(String[] args)
	{
	
	head1 = getData(head1, 10);
	head1 = getData(head1, 5);
	head1 = getData(head1, 15);

	head2 = getData(head2, 20);
	head2 = getData(head2, 3);
	head2 = getData(head2, 2);
	
	head1 = mergelists();

	sortlist();

	setData(head1);
	}
	}