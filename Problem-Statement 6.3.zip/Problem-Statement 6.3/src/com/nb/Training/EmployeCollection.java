package com.nb.Training;

import java.util.LinkedList;

public class EmployeCollection {

	private static final Employe[] v = null;

	public static void main(String[] args) {
		LinkedList<Employe> v = addInput();
		display(v);
	}

	private static LinkedList<Employe> addInput() {
		Employe e1 = new Employe(101, "Nb", "Pune");
		Employe e2 = new Employe(102, "Ab", "Hyd");
		Employe e3 = new Employe(103, "Lilly", "bang");
		LinkedList<Employe> v = new LinkedList<Employe>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
	}

	private static void display(LinkedList<Employe> v) {
		for (Employe e : v) {
			System.out.println(e.getEmpid() + "\t" + e.getEname() + "\t" + e.getAddress());
		}
	}

}
