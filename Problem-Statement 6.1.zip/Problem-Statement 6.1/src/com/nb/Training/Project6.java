package com.nb.Training;

import java.util.ArrayList;

public class Project6 {
	public static void main(String[] args) {
		ArrayList<String> alist=new ArrayList<String>();//Creating arraylist  
	    alist.add("ABC");//Adding object in arraylist  
	    alist.add("BCD");  
	    alist.add("CDE");  
	    alist.add("DEF");
	  
	    System.out.println(alist);
	    
	    if (alist.contains("ABC"))
	        System.out.println("ABC exists in the ArrayList");

	    else
	        System.out.println("ABC does not exist in the ArrayList");

	    if (alist.contains("CDE"))
	        System.out.println("CDE exists in the ArrayList");

	    else
	        System.out.println("CDE does not exist in the ArrayList");
	    
	}
	}